// ============================================================
//  AdContractIQ — WWE Demo Mock Data
//  Synthetic Netflix × TKO Group Holdings / WWE contract
//  Exhibit D — Ad Revenue Share Schedule
// ============================================================

export const MOCK_EXTRACTED_DATA = {
  classification: {
    contract_type: "master_agreement",
    partner_type: "content_partner",
    complexity: "complex",
    revenue_model: ["revenue_share", "cpm", "threshold"],
    confidence: 0.97
  },

  contract_info: {
    partner_name: "TKO Group Holdings / WWE",
    effective_date: "January 1, 2025",
    expiration_date: "December 31, 2034",
    document_type: "Live Programming & Ad Revenue Share Agreement — Exhibit D",
    payment_term: "Net 45",
    business_type: "Content Partner",
    key_terms: [
      "20% COS applies to all ad revenue before any split",
      "Rule 1 CPM ladder: <$30 (100/0), $30–$50 (80/20), >$50 (70/30)",
      "Rule 1 Title Sponsorship: always 60/40 regardless of CPM",
      "Rule 2 PLE: $15M quarterly threshold — WWE earns $0 below it",
      "Rule 2 In-Ring Integration: always 50/50, bypasses threshold",
      "Rule 3 VOD Archive: flat 70/30 split, no threshold",
      "US and International ledgers tracked independently",
      "Rule 2 US effective January 1, 2026 (PLEs left Peacock)"
    ]
  },

  // Grouped rules for demo mode
  rules: [
    // Rule 1 group — represented as single rule with sub_rules
    {
      rule_number: 1,
      rule_group_id: "rule_1",
      rule_group_label: "Rule 1 — Weekly Live Programming",
      rule_text: "Netflix sells all ad inventory against Raw (US) and Raw + SmackDown + NXT (International). 20% COS applies first. Revenue then splits based on monthly blended CPM tier. Title Sponsorships always split 60/40.",
      confidence: 0.98,
      source: "Exhibit D — Rule 1, Page 1",
      source_page: 1,
      category: "revenue_share",
      approved: false,
      is_calculable: true,
      calculation_type: "tiered",
      sub_rules: [
        { label: "Below $30 CPM", split: "100% Netflix / 0% WWE", note: "Sub-baseline performance" },
        { label: "$30–$50 CPM", split: "80% Netflix / 20% WWE", note: "Baseline to premium band (~$38 CPM typical)" },
        { label: "Above $50 CPM", split: "70% Netflix / 30% WWE", note: "Sold-out premium inventory" },
        { label: "Title Sponsorship", split: "60% Netflix / 40% WWE", note: "Any CPM — mutual pre-approval required" },
      ]
    },
    // Rule 2 group
    {
      rule_number: 2,
      rule_group_id: "rule_2",
      rule_group_label: "Rule 2 — Premium Live Events",
      rule_text: "WWE earns $0 in rev share until Netflix's quarterly PLE net revenue exceeds the $15M Rights Recovery Tranche. Above the threshold, WWE earns 40%. In-Ring Integrations always split 50/50, bypassing the threshold entirely. US effective Jan 2026; International from Jan 2025.",
      confidence: 0.96,
      source: "Exhibit D — Rule 2, Page 2",
      source_page: 2,
      category: "revenue_share",
      approved: false,
      is_calculable: true,
      calculation_type: "threshold",
      sub_rules: [
        { label: "Below $15M threshold", split: "100% Netflix / 0% WWE", note: "Rights Recovery Tranche — WWE earns nothing" },
        { label: "Above $15M threshold", split: "60% Netflix / 40% WWE", note: "No cap on WWE upside" },
        { label: "In-Ring Integration", split: "50% Netflix / 50% WWE", note: "Match naming, LED boards, pyro — always 50/50" },
      ]
    },
    // Rule 3
    {
      rule_number: 3,
      rule_group_id: "rule_3",
      rule_group_label: "Rule 3 — VOD Archive",
      rule_text: "The entire WWE content archive (50,000+ hours) is available on Netflix globally. All archive ad inventory is sold by Netflix. After 20% COS, revenue splits 70/30 Netflix/WWE. No thresholds, no CPM ladders — flat split on all qualified archive revenue.",
      confidence: 0.99,
      source: "Exhibit D — Rule 3, Page 4",
      source_page: 4,
      category: "revenue_share",
      approved: false,
      is_calculable: true,
      calculation_type: "percentage",
      sub_rules: [
        { label: "All archive content", split: "70% Netflix / 30% WWE", note: "Historic PPVs, weekly archive, docs, specials" },
      ]
    }
  ],

  glossary: {
    "COS": "Cost of Sale — 20% of Gross Revenue deducted before any split",
    "Net Qualified Revenue": "Gross Revenue less 20% COS",
    "Rights Recovery Tranche": "$15M quarterly threshold Netflix retains before sharing PLE revenue with WWE",
    "In-Ring Integration": "Branded placements including match naming, LED boards, and pyro branding — always 50/50",
    "CPM": "Cost Per Mille — revenue per 1,000 ad impressions"
  },

  summary: "This is a Live Programming & Ad Revenue Share Agreement (Exhibit D) between Netflix, Inc. and TKO Group Holdings / WWE, effective January 1, 2025 through December 31, 2034. The agreement governs three separate ad revenue pipelines: Rule 1 covers weekly live programming with a CPM-tiered split (Raw exclusively in the US; Raw, SmackDown, and NXT internationally); Rule 2 covers Premium Live Events with a $15M quarterly rights recovery threshold before WWE earns 40%; and Rule 3 covers the 50,000+ hour VOD archive at a flat 70/30 split. All rules apply 20% COS before any revenue sharing. US and International ledgers are maintained independently.",

  extraction_stats: {
    total_rules_found: 3,
    calculable_rules: 3,
    skipped_rules: 4,
    skipped_reasons: ["payment timing", "audit rights", "dispute window", "bank account controls"]
  }
}

// ============================================================
//  Mock Expressions — WWE Rule 1 worked example
//  Based on contract's own monthly calculations (Page 2)
// ============================================================

export const MOCK_EXPRESSIONS = {
  calculation_chains: [
    {
      chain_id: "chain_us_raw",
      label: "Rule 1 — US Raw Monthly (Standard $40 CPM)",
      description: "Monthly ad revenue calculation for Monday Night Raw — US market. $40 CPM falls in the $30–$50 band, triggering 80/20 split after 20% COS.",
      steps: [
        {
          step_number: 1,
          operation: "subtract",
          label: "Deduct Cost of Sale",
          formula: "Gross_Revenue × 20%",
          formula_display: "$100 × 20%",
          result: 20,
          running_total: 80,
          display: "$100.00 − $20.00 (20% COS) = $80.00 Net Qualified Revenue",
          rule_references: [1]
        },
        {
          step_number: 2,
          operation: "conditional",
          label: "Determine CPM Tier",
          formula: "$40 CPM → $30–$50 band → 80/20 split",
          formula_display: "Blended CPM $40 → Band: $30–$50",
          result: 0.80,
          running_total: 80,
          display: "$40 CPM falls in $30–$50 band — Netflix 80% / WWE 20%",
          rule_references: [1]
        },
        {
          step_number: 3,
          operation: "multiply",
          label: "Apply Netflix Share (80%)",
          formula: "Net_Qualified_Revenue × 80%",
          formula_display: "$80.00 × 80%",
          result: 64,
          running_total: 64,
          display: "$80.00 × 80% = $64.00 to Netflix",
          rule_references: [1]
        },
        {
          step_number: 4,
          operation: "multiply",
          label: "Apply WWE Share (20%)",
          formula: "Net_Qualified_Revenue × 20%",
          formula_display: "$80.00 × 20%",
          result: 16,
          running_total: 16,
          display: "$80.00 × 20% = $16.00 to WWE",
          rule_references: [1]
        }
      ],
      final_amounts: {
        "Netflix": 64,
        "WWE": 16
      }
    },
    {
      chain_id: "chain_us_title",
      label: "Rule 1 — US Raw Monthly (Title Sponsorship)",
      description: "Title Sponsorship (e.g. Snickers presenting sponsor) always splits 60/40 regardless of CPM. Flat-fee presenting deal.",
      steps: [
        {
          step_number: 1,
          operation: "subtract",
          label: "Deduct Cost of Sale",
          formula: "Gross_Revenue × 20%",
          formula_display: "$100 × 20%",
          result: 20,
          running_total: 80,
          display: "$100.00 − $20.00 (20% COS) = $80.00 Net Qualified Revenue",
          rule_references: [1]
        },
        {
          step_number: 2,
          operation: "multiply",
          label: "Apply Netflix Share (60% — always)",
          formula: "Net_Qualified_Revenue × 60%",
          formula_display: "$80.00 × 60%",
          result: 48,
          running_total: 48,
          display: "Title Sponsorship: always 60/40 regardless of CPM → $48.00 Netflix",
          rule_references: [1]
        },
        {
          step_number: 3,
          operation: "multiply",
          label: "Apply WWE Share (40% — always)",
          formula: "Net_Qualified_Revenue × 40%",
          formula_display: "$80.00 × 40%",
          result: 32,
          running_total: 32,
          display: "$80.00 × 40% = $32.00 to WWE",
          rule_references: [1]
        }
      ],
      final_amounts: {
        "Netflix": 48,
        "WWE": 32
      }
    },
    {
      chain_id: "chain_intl",
      label: "Rule 1 — International Monthly (Raw + SmackDown + NXT)",
      description: "Netflix holds international rights to all three weekly shows. Combined pool is ~3× Raw US. $40 CPM blended across all three shows.",
      steps: [
        {
          step_number: 1,
          operation: "subtract",
          label: "Deduct Cost of Sale",
          formula: "Gross_Revenue × 20%",
          formula_display: "$100 × 20%",
          result: 20,
          running_total: 80,
          display: "$100.00 − $20.00 (20% COS) = $80.00 Net Qualified Revenue",
          rule_references: [1]
        },
        {
          step_number: 2,
          operation: "conditional",
          label: "Determine CPM Tier",
          formula: "$40 CPM → $30–$50 band → 80/20 split",
          formula_display: "Blended CPM $40 → Band: $30–$50",
          result: 0.80,
          running_total: 80,
          display: "$40 blended CPM across Raw/SD/NXT → 80/20 split applies",
          rule_references: [1]
        },
        {
          step_number: 3,
          operation: "multiply",
          label: "Apply Netflix Share (80%)",
          formula: "Net_Qualified_Revenue × 80%",
          formula_display: "$80.00 × 80%",
          result: 64,
          running_total: 64,
          display: "$80.00 × 80% = $64.00 to Netflix",
          rule_references: [1]
        },
        {
          step_number: 4,
          operation: "multiply",
          label: "Apply WWE Share (20%)",
          formula: "Net_Qualified_Revenue × 20%",
          formula_display: "$80.00 × 20%",
          result: 16,
          running_total: 16,
          display: "$80.00 × 20% = $16.00 to WWE",
          rule_references: [1]
        }
      ],
      final_amounts: {
        "Netflix": 64,
        "WWE": 16
      }
    }
  ],
  summary: {
    total_chains: 3,
    rules_used: [1],
    rules_not_used: [2, 3],
    notes: "Rule 1 monthly calculations based on contract Exhibit D Page 2 worked examples. Title Sponsorship and Standard inventory calculated separately as they apply different splits. International pool is Raw + SmackDown + NXT combined (~3× Raw US impressions)."
  }
}

// ============================================================
//  WWE Synthetic Revenue CSV Data
//  Mirrors OneFootball CSV structure, adapted for WWE/Netflix
// ============================================================

export const MOCK_WWE_CSV_ROWS = [
  // Rule 1 — US Raw Standard (various CPM tiers)
  {
    period: "JAN-25",
    contract: "NF-WWE-2025-001",
    name: "Monday Night Raw — US (Standard)",
    territory: "US",
    ad_type: "Standard",
    impressions: 22000000,
    gross_revenue: 836000,
    cpm: 38.00,
    cos_pct: 20
  },
  {
    period: "JAN-25",
    contract: "NF-WWE-2025-001",
    name: "Monday Night Raw — US (Title Sponsorship)",
    territory: "US",
    ad_type: "Title Sponsorship",
    impressions: null,
    gross_revenue: 1000000,
    cpm: null,
    cos_pct: 20
  },
  // Rule 1 — International
  {
    period: "JAN-25",
    contract: "NF-WWE-2025-001",
    name: "Monday Night Raw — International",
    territory: "International",
    ad_type: "Standard",
    impressions: 28000000,
    gross_revenue: 1064000,
    cpm: 38.00,
    cos_pct: 20
  },
  {
    period: "JAN-25",
    contract: "NF-WWE-2025-001",
    name: "SmackDown — International",
    territory: "International",
    ad_type: "Standard",
    impressions: 19000000,
    gross_revenue: 722000,
    cpm: 38.00,
    cos_pct: 20
  },
  {
    period: "JAN-25",
    contract: "NF-WWE-2025-001",
    name: "NXT — International",
    territory: "International",
    ad_type: "Standard",
    impressions: 8500000,
    gross_revenue: 272000,
    cpm: 32.00,
    cos_pct: 20
  },
  // High CPM scenario (above $50)
  {
    period: "JAN-25",
    contract: "NF-WWE-2025-001",
    name: "Monday Night Raw — US (Royal Rumble Go-Home)",
    territory: "US",
    ad_type: "Standard",
    impressions: 26000000,
    gross_revenue: 1430000,
    cpm: 55.00,
    cos_pct: 20
  },
  // Below $30 CPM scenario
  {
    period: "JAN-25",
    contract: "NF-WWE-2025-001",
    name: "NXT — International (Off-Peak)",
    territory: "International",
    ad_type: "Standard",
    impressions: 4200000,
    gross_revenue: 100800,
    cpm: 24.00,
    cos_pct: 20
  },
]

// ============================================================
//  Apply Rule 1 logic to a CSV row
// ============================================================

export function applyRule1(row) {
  const cos_amount = row.gross_revenue * (row.cos_pct / 100)
  const net_qualified = row.gross_revenue - cos_amount

  let netflix_pct, wwe_pct, tier_label

  if (row.ad_type === "Title Sponsorship") {
    netflix_pct = 60
    wwe_pct = 40
    tier_label = "Title Sponsorship (always 60/40)"
  } else if (row.cpm === null || row.cpm < 30) {
    netflix_pct = 100
    wwe_pct = 0
    tier_label = "Below $30 CPM (100/0)"
  } else if (row.cpm <= 50) {
    netflix_pct = 80
    wwe_pct = 20
    tier_label = "$30–$50 CPM (80/20)"
  } else {
    netflix_pct = 70
    wwe_pct = 30
    tier_label = "Above $50 CPM (70/30)"
  }

  const netflix_share = net_qualified * (netflix_pct / 100)
  const wwe_share = net_qualified * (wwe_pct / 100)

  return {
    ...row,
    cos_amount,
    net_qualified,
    netflix_pct,
    wwe_pct,
    tier_label,
    netflix_share,
    wwe_share
  }
}

// ============================================================
//  Generate downloadable CSV string from results
// ============================================================

export function generateOutputCSV(results) {
  const headers = [
    "Period", "Contract", "Name", "Territory", "Ad Type",
    "Impressions", "Gross Revenue", "COS %", "COS Amount",
    "Net Qualified Revenue", "CPM", "Tier Applied",
    "Netflix %", "WWE %", "Netflix Share", "WWE Share"
  ]

  const fmt = (n) => n === null || n === undefined ? "" : Number(n).toFixed(2)
  const fmtPct = (n) => n === null || n === undefined ? "" : `${n}%`
  const fmtImpr = (n) => n === null || n === undefined ? "" : n.toLocaleString()

  const rows = results.map(r => [
    r.period,
    r.contract,
    r.name,
    r.territory,
    r.ad_type,
    fmtImpr(r.impressions),
    fmt(r.gross_revenue),
    fmtPct(r.cos_pct),
    fmt(r.cos_amount),
    fmt(r.net_qualified),
    r.cpm ? fmt(r.cpm) : "N/A",
    r.tier_label,
    fmtPct(r.netflix_pct),
    fmtPct(r.wwe_pct),
    fmt(r.netflix_share),
    fmt(r.wwe_share)
  ])

  return [headers, ...rows]
    .map(row => row.map(field => `"${field}"`).join(","))
    .join("\n")
}

// Simulate API delay
export const simulateAPIDelay = (min = 800, max = 1500) => {
  const delay = Math.floor(Math.random() * (max - min + 1)) + min
  return new Promise(resolve => setTimeout(resolve, delay))
}
