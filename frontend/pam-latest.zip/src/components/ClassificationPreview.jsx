import React, { useState } from 'react'
import { CONFIG } from '../config'

function AccordionSection({ title, children, defaultOpen = true }) {
  const [isOpen, setIsOpen] = useState(defaultOpen)
  return (
    <div className="cp-accordion-section">
      <button className="cp-accordion-header" onClick={() => setIsOpen(!isOpen)}>
        <span className="cp-accordion-title">{title}</span>
        <span className={`cp-accordion-chevron ${isOpen ? 'open' : ''}`}>›</span>
      </button>
      {isOpen && <div className="cp-accordion-body">{children}</div>}
    </div>
  )
}

function ClassificationPreview({ data, onBack, onContinue, isLoading }) {
  if (!data) return null

  const formatClassificationType = (type) => {
    if (!type) return 'Unknown'
    return type.split('_').map(word =>
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ')
  }

  return (
    <div className="extracted-container">

      <div className="cp-page-header">
        <h2 className="cp-page-title">Contract Preview</h2>
        <p className="cp-page-subtitle">
          Review the contract information before processing full extraction.
        </p>
      </div>

      <div className="cp-accordion-container">
        <AccordionSection title="Contract Key Information">
          <div className="cp-grid">
            <div className="cp-row">
              <span className="cp-label">Contract Type</span>
              <span className="cp-value">New</span>
            </div>
            <div className="cp-row">
              <span className="cp-label">Business Type</span>
              <span className="cp-value">Media Partner</span>
            </div>
            <div className="cp-row">
              <span className="cp-label">Partner</span>
              <span className="cp-value">{data.contract_info?.partner_name || 'Unknown'}</span>
            </div>
            <div className="cp-row">
              <span className="cp-label">Effective Start Date</span>
              <span className="cp-value">{data.contract_info?.effective_date || 'N/A'}</span>
            </div>
            <div className="cp-row">
              <span className="cp-label">Effective End Date</span>
              <span className="cp-value">{data.contract_info?.expiration_date || 'N/A'}</span>
            </div>
            <div className="cp-row">
              <span className="cp-label">Payment Term</span>
              <span className="cp-value">{data.contract_info?.payment_term || 'Net 45'}</span>
            </div>
            <div className="cp-row">
              <span className="cp-label">Payout Complexity</span>
              <span className="cp-value">Moderate</span>
            </div>
            <div className="cp-row">
              <span className="cp-label">AI Confidence</span>
              <div className="cp-confidence">
                <div className="cp-confidence-bar">
                  <div
                    className="cp-confidence-fill"
                    style={{
                      width: `${(data.classification?.confidence || 0.97) * 100}%`,
                      backgroundColor: '#46d369'
                    }}
                  />
                </div>
                <span className="cp-confidence-pct">
                  {((data.classification?.confidence || 0.97) * 100).toFixed(0)}%
                </span>
              </div>
            </div>
          </div>
        </AccordionSection>

        {data.summary && (
          <AccordionSection title="Contract Summary" defaultOpen={false}>
            <p className="cp-summary-text">{data.summary}</p>
          </AccordionSection>
        )}
      </div>

      <div className="cp-actions">
        <button className="cp-btn-back" onClick={onBack} disabled={isLoading}>
          Back
        </button>
        <button className="cp-btn-continue" onClick={onContinue} disabled={isLoading}>
          {isLoading ? <><span className="spinner" /> Processing…</> : 'Continue Processing'}
        </button>
      </div>

    </div>
  )
}

export default ClassificationPreview
