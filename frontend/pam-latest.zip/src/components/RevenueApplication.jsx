import React, { useState, useRef } from 'react'
import { applyRule1, generateOutputCSV } from '../utils/mockData'

function RevenueApplication({ onBack }) {
  const [rows, setRows] = useState([])
  const [results, setResults] = useState([])
  const [hasFile, setHasFile] = useState(false)
  const [fileName, setFileName] = useState('')
  const [isApplied, setIsApplied] = useState(false)
  const [error, setError] = useState('')
  const fileInputRef = useRef(null)

  const parseCSV = (text) => {
    const lines = text.trim().split('\n')
    // Skip header rows — find the data start
    // Expect: Period, Contract, Name, Territory, Ad Type, Impressions, Gross Revenue, COS %
    const headerIdx = lines.findIndex(l =>
      l.toLowerCase().includes('period') && l.toLowerCase().includes('gross')
    )
    if (headerIdx === -1) throw new Error('Could not find header row. Expected columns: Period, Name, Territory, Ad Type, Impressions, Gross Revenue, COS %')

    const parseCSVLine = (line) => {
      const result = []
      let current = ''
      let inQuotes = false
      for (let i = 0; i < line.length; i++) {
        const char = line[i]
        if (char === '"') { inQuotes = !inQuotes }
        else if (char === ',' && !inQuotes) { result.push(current.trim()); current = '' }
        else { current += char }
      }
      result.push(current.trim())
      return result
    }

    const headers = parseCSVLine(lines[headerIdx]).map(h => h.toLowerCase().replace(/[^a-z0-9]/g, '_'))
    const parsed = []

    for (let i = headerIdx + 1; i < lines.length; i++) {
      if (!lines[i].trim()) continue
      const vals = parseCSVLine(lines[i])
      const row = {}
      headers.forEach((h, idx) => { row[h] = vals[idx] || '' })

      const grossRevenue = parseFloat(row['gross_revenue']?.replace(/,/g, '') || '0')
      const impressions = parseFloat(row['impressions']?.replace(/,/g, '') || '0') || null
      const cpm = impressions ? parseFloat((grossRevenue / impressions * 1000).toFixed(2)) : null

      if (!isNaN(grossRevenue) && grossRevenue > 0) {
        parsed.push({
          period: row['period'] || '',
          contract: row['contract'] || '',
          name: row['name'] || '',
          territory: row['territory'] || '',
          ad_type: row['ad_type'] || 'Standard',
          impressions: impressions || null,
          gross_revenue: grossRevenue,
          cpm,
          cos_pct: parseInt(row['cos__'] || row['cos_pct'] || '20')
        })
      }
    }

    return parsed
  }

  const handleFileUpload = (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!file.name.toLowerCase().endsWith('.csv')) {
      setError('Please upload a CSV file')
      return
    }
    setFileName(file.name)
    setError('')
    setIsApplied(false)
    setResults([])

    const reader = new FileReader()
    reader.onload = (evt) => {
      try {
        const parsed = parseCSV(evt.target.result)
        if (parsed.length === 0) { setError('No valid data rows found in CSV'); return }
        setRows(parsed)
        setHasFile(true)
      } catch (err) {
        setError(err.message)
      }
    }
    reader.readAsText(file)
    e.target.value = ''
  }

  const handleApplyRules = () => {
    if (!hasFile) {
      setError('Please upload a CSV file to apply rules.')
      return
    }
    const calculated = rows.map(row => applyRule1(row))
    setResults(calculated)
    setIsApplied(true)
  }

  const handleDownload = () => {
    const csv = generateOutputCSV(results)
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `wwe-revshare-output-${new Date().toISOString().split('T')[0]}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  const fmt = (n) => n === null || n === undefined ? '—' :
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2 }).format(n)

  const displayRows = hasFile ? rows : []

  return (
    <div className="ra-container">

      <div className="fo-top-row">
        <div className="cp-page-header" style={{ marginBottom: 0 }}>
          <h2 className="cp-page-title">Partner Payout Data Simulation</h2>
        </div>
        {isApplied && (
          <div className="fo-export-row">
            <button className="cp-btn-continue" onClick={handleDownload}>
              Download CSV
            </button>
          </div>
        )}
      </div>

      {/* Upload */}
      <div className="cp-accordion-container">
        <div className="cp-accordion-section">
          <div className="cp-accordion-header" style={{ cursor: 'default' }}>
            <span className="cp-accordion-title">Revenue Data</span>
            <div className="fo-export-row">
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv"
                onChange={handleFileUpload}
                style={{ display: 'none' }}
              />
              {hasFile ? (
                <span className="cp-page-subtitle" style={{ fontSize: '0.8rem' }}>
                  {fileName} — {rows.length} rows
                  <button
                    className="rr-btn-delete"
                    style={{ marginLeft: '0.5rem' }}
                    onClick={() => { setHasFile(false); setRows([]); setResults([]); setIsApplied(false); setFileName('') }}
                  >
                    Remove
                  </button>
                </span>
              ) : (
                <button className="rr-btn-verify" onClick={() => fileInputRef.current?.click()}>
                  Upload Delivery Data
                </button>
              )}
            </div>
          </div>

          {/* Preview table */}
          <div className="cp-accordion-body">
            {error && <div className="error-message" style={{ marginBottom: '0.75rem' }}>{error}</div>}

            <div className="ra-table-wrapper">
              <table className="ra-table">
                <thead>
                  <tr>
                    <th>Period</th>
                    <th>Name</th>
                    <th>Territory</th>
                    <th>Ad Type</th>
                    <th>Impressions</th>
                    <th>Gross Revenue</th>
                    <th>CPM</th>
                    {isApplied && <>
                      <th>COS</th>
                      <th>Net Qualified</th>
                      <th>Tier</th>
                      <th>WWE %</th>
                      <th className="ra-highlight-wwe">WWE Payout</th>
                    </>}
                  </tr>
                </thead>
                <tbody>
                  {(isApplied ? results : displayRows).map((row, i) => (
                    <tr key={i}>
                      <td>{row.period}</td>
                      <td className="ra-name">{row.name}</td>
                      <td>{row.territory}</td>
                      <td>{row.ad_type}</td>
                      <td className="ra-num">{row.impressions ? row.impressions.toLocaleString() : '—'}</td>
                      <td className="ra-num">{fmt(row.gross_revenue)}</td>
                      <td className="ra-num">{row.cpm ? `$${row.cpm.toFixed(2)}` : 'N/A'}</td>
                      {isApplied && <>
                        <td className="ra-num">{fmt(row.cos_amount)}</td>
                        <td className="ra-num">{fmt(row.net_qualified)}</td>
                        <td className="ra-tier">{row.tier_label}</td>
                        <td className="ra-num">{row.wwe_pct}%</td>
                        <td className="ra-num ra-highlight-wwe">{fmt(row.wwe_share)}</td>
                      </>}
                    </tr>
                  ))}
                </tbody>
                {isApplied && results.length > 0 && (
                  <tfoot>
                    <tr className="ra-totals">
                      <td colSpan={7}><strong>Totals</strong></td>
                      <td className="ra-num"><strong>{fmt(results.reduce((s, r) => s + r.cos_amount, 0))}</strong></td>
                      <td className="ra-num"><strong>{fmt(results.reduce((s, r) => s + r.net_qualified, 0))}</strong></td>
                      <td colSpan={2}></td>
                      <td className="ra-num ra-highlight-wwe"><strong>{fmt(results.reduce((s, r) => s + r.wwe_share, 0))}</strong></td>
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="cp-actions" style={{ marginTop: '0.75rem' }}>
        <button className="cp-btn-back" onClick={onBack}>Back to Rules</button>
        {!isApplied ? (
          <button className="cp-btn-continue" onClick={handleApplyRules} disabled={!hasFile}>
            Apply Rules
          </button>
        ) : (
          <button className="cp-btn-continue" onClick={() => alert('Submitted for approval!')}>
            Submit For Approval
          </button>
        )}
      </div>

    </div>
  )
}

export default RevenueApplication
