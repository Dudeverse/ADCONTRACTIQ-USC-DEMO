import React, { useState } from 'react'
import { CONFIG } from '../config'
import { MOCK_EXPRESSIONS, simulateAPIDelay } from '../utils/mockData'
import EnhancedPDFViewer from './EnhancedPDFViewer'

// ── Rule reference lookup for View Source ─────────────────
const RULE_SOURCE_PAGES = {
  1: 1,
  2: 2,
  3: 4,
}

// ── EBChain — calculation chain accordion ─────────────────
function EBChain({ chain, index, expandedChains, toggleChain, formatCurrency, getOperationSymbol, approvedRules, pdfFile }) {
  const [pdfOpen, setPdfOpen] = useState(false)
  const [pdfPage, setPdfPage] = useState(1)
  const isOpen = expandedChains[index]

  const openSource = (ruleRefs) => {
    const firstRef = ruleRefs?.[0]
    const page = RULE_SOURCE_PAGES[firstRef] || 1
    setPdfPage(page)
    setPdfOpen(true)
  }

  // Find the approved rules referenced by this chain
  const chainRuleNums = new Set(chain.steps?.flatMap(s => s.rule_references || []))
  const referencedRules = approvedRules?.filter(r => chainRuleNums.has(r.rule_number)) || []

  return (
    <>
      <div className="cp-accordion-section">
        <button className="cp-accordion-header" onClick={() => toggleChain(index)}>
          <span className="cp-accordion-title">{chain.label}</span>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            {chain.steps?.length > 0 && (
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                {chain.steps.length} steps
              </span>
            )}
            <span className={`cp-accordion-chevron ${isOpen ? 'open' : ''}`}>›</span>
          </div>
        </button>

        {isOpen && (
          <div className="cp-accordion-body">
            {chain.description && (
              <p className="cp-summary-text" style={{ marginBottom: '1rem' }}>{chain.description}</p>
            )}

            {/* Approved rules driving this chain */}
            {referencedRules.length > 0 && (
              <div className="eb-source-rules">
                <span className="eb-final-label">Rules Applied</span>
                {referencedRules.map(rule => (
                  <div key={rule.rule_number} className="eb-source-rule-row">
                    <span className="cp-summary-text" style={{ flex: 1 }}>
                      {rule.rule_group_label || `Rule ${rule.rule_number}`}
                    </span>
                    <button
                      className="rr-btn-verify"
                      onClick={() => openSource([rule.rule_number])}
                    >
                      View Source
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Steps */}
            <div className="eb-steps-list">
              {chain.steps?.map((step, stepIdx) => (
                <div key={stepIdx} className="eb-step-card">
                  <div className="eb-step-card-header">
                    <span className="eb-step-num">{step.step_number}</span>
                    <span className="eb-step-label">{step.label}</span>
                    {step.rule_references?.length > 0 && (
                      <span className="eb-rule-ref">Rule {step.rule_references.join(', ')}</span>
                    )}
                  </div>
                  {step.formula_display && (
                    <div className="eb-step-formula">{step.formula_display}</div>
                  )}
                  {step.display && (
                    <div className="eb-step-display">{step.display}</div>
                  )}
                  <div className="eb-step-amounts">
                    <span className="eb-step-op">{getOperationSymbol(step.operation)}</span>
                    <span className="eb-step-result">{formatCurrency(step.result)}</span>
                    {step.running_total !== undefined && (
                      <span className="eb-running-total">→ {formatCurrency(step.running_total)}</span>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Final amounts */}
            {chain.final_amounts && Object.keys(chain.final_amounts).length > 0 && (
              <div className="eb-final-amounts">
                <span className="eb-final-label">Final Distribution</span>
                {Object.entries(chain.final_amounts).map(([party, amount]) => (
                  <div key={party} className="eb-final-row">
                    <span className="cp-label">{party}</span>
                    <span className="eb-final-amount">{formatCurrency(amount)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      <EnhancedPDFViewer
        file={pdfFile}
        isOpen={pdfOpen}
        onClose={() => setPdfOpen(false)}
        embedded={false}
        initialPage={pdfPage}
      />
    </>
  )
}

// ── EBSummary — collapsed summary ─────────────────────────
function EBSummary({ expressions, baseRevenue, setBaseRevenue, buildExpressions }) {
  const [isOpen, setIsOpen] = useState(false)
  return (
    <div className="cp-accordion-section">
      <button className="cp-accordion-header" onClick={() => setIsOpen(!isOpen)}>
        <span className="cp-accordion-title">Summary</span>
        <span className={`cp-accordion-chevron ${isOpen ? 'open' : ''}`}>›</span>
      </button>
      {isOpen && (
        <div className="cp-accordion-body">
          <div className="cp-grid">
            <div className="cp-row">
              <span className="cp-label">Calculation chains</span>
              <span className="cp-value">{expressions.calculation_chains.length}</span>
            </div>
            <div className="cp-row">
              <span className="cp-label">Rules used</span>
              <span className="cp-value">{expressions.summary?.rules_used?.length || 0}</span>
            </div>
            <div className="cp-row">
              <span className="cp-label">Total steps</span>
              <span className="cp-value">{expressions.calculation_chains.reduce((sum, c) => sum + (c.steps?.length || 0), 0)}</span>
            </div>
            <div className="cp-row">
              <span className="cp-label">Recalculate with revenue</span>
              <div className="eb-revenue-input-row">
                <span className="eb-currency">$</span>
                <input
                  type="number"
                  className="eb-revenue-input"
                  value={baseRevenue}
                  onChange={(e) => setBaseRevenue(Number(e.target.value))}
                  min="1"
                  step="100"
                />
                <button
                  className="rr-btn-verify"
                  style={{ marginLeft: '0.5rem' }}
                  onClick={() => buildExpressions(baseRevenue)}
                >
                  Apply
                </button>
              </div>
            </div>
            {expressions.summary?.notes && (
              <div className="cp-row">
                <span className="cp-label">Notes</span>
                <span className="cp-value" style={{ textAlign: 'right', maxWidth: '60%' }}>
                  {expressions.summary.notes}
                </span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

// ── Main ExpressionBuilder ─────────────────────────────────
function ExpressionBuilder({ data, existingExpressions, onExpressionsBuilt, onBack, onReset, onContinue, pdfFile }) {
  const [expressions, setExpressions] = useState(existingExpressions || null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState(null)
  const [expandedChains, setExpandedChains] = useState({})
  const [baseRevenue, setBaseRevenue] = useState(100)

  React.useEffect(() => {
    if (existingExpressions) {
      setExpressions(existingExpressions)
      if (existingExpressions.calculation_chains?.length > 0) {
        setExpandedChains({ 0: true })
      }
    }
  }, [existingExpressions])

  const buildExpressions = async (customBaseRevenue = null) => {
    setIsLoading(true)
    setError(null)
    try {
      if (CONFIG.ENABLE_DEMO_MODE) {
        await simulateAPIDelay(1000, 1800)
        const result = MOCK_EXPRESSIONS
        setExpressions(result)
        if (onExpressionsBuilt) onExpressionsBuilt(result)
        if (result.calculation_chains?.length > 0) setExpandedChains({ 0: true })
        setIsLoading(false)
        return
      }

      const payload = {
        contract_info: data.contractInfo || {},
        finalized_rules: data.rules || [],
        glossary: data.glossary || {},
        base_revenue: customBaseRevenue || baseRevenue,
        execution_id: data.execution_id || data.pdf_id
      }
      const response = await fetch(CONFIG.N8N_EXPRESSIONS_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      if (!response.ok) throw new Error(`Server error: ${response.status}`)
      const result = await response.json()
      if (result.error) throw new Error(result.message || 'Failed to build expressions')
      setExpressions(result)
      if (onExpressionsBuilt) onExpressionsBuilt(result)
      if (result.calculation_chains?.length > 0) setExpandedChains({ 0: true })
    } catch (err) {
      setError(err.message)
    } finally {
      setIsLoading(false)
    }
  }

  const toggleChain = (index) => setExpandedChains(prev => ({ ...prev, [index]: !prev[index] }))

  const formatCurrency = (amount) => new Intl.NumberFormat('en-US', {
    style: 'currency', currency: 'USD',
    minimumFractionDigits: 2, maximumFractionDigits: 2
  }).format(amount)

  const getOperationSymbol = (op) => ({ add: '+', subtract: '−', multiply: '×', divide: '÷', max: 'max', min: 'min', conditional: '→' })[op] || op

  const downloadExpressions = () => {
    const blob = new Blob([JSON.stringify(expressions, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `expressions-${Date.now()}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  const approvedRules = data.rules || []

  return (
    <div className="expression-builder-container">

      {/* Pre-build screen */}
      {!expressions && (
        <div className="extracted-container">
          <div className="cp-page-header">
            <h2 className="cp-page-title">Expression Builder</h2>
            <p className="cp-page-subtitle">
              Build step-by-step calculation chains from your {data.rules?.length || 0} finalized rules.
            </p>
          </div>

          <div className="cp-accordion-container">
            <div className="cp-accordion-section">
              <div className="cp-accordion-header" style={{ cursor: 'default' }}>
                <span className="cp-accordion-title">Configuration</span>
              </div>
              <div className="cp-accordion-body">
                <div className="cp-grid">
                  <div className="cp-row">
                    <span className="cp-label">Rules to process</span>
                    <span className="cp-value">{data.rules?.length || 0}</span>
                  </div>
                  <div className="cp-row">
                    <span className="cp-label">Sample base revenue</span>
                    <div className="eb-revenue-input-row">
                      <span className="eb-currency">$</span>
                      <input
                        type="number"
                        className="eb-revenue-input"
                        value={baseRevenue}
                        onChange={(e) => setBaseRevenue(Number(e.target.value))}
                        min="1"
                        step="100"
                      />
                    </div>
                  </div>
                  {data.contractInfo?.partner_name && (
                    <div className="cp-row">
                      <span className="cp-label">Partner</span>
                      <span className="cp-value">{data.contractInfo.partner_name}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {error && <div className="error-message" style={{ marginBottom: '0.75rem' }}>{error}</div>}

          <div className="cp-actions">
            <button className="cp-btn-back" onClick={onBack} disabled={isLoading}>Back to RevShare Rules</button>
            <button className="cp-btn-continue" onClick={() => buildExpressions()} disabled={isLoading}>
              {isLoading ? <><span className="spinner" /> Building…</> : 'Build Expressions'}
            </button>
          </div>
        </div>
      )}

      {/* Post-build screen */}
      {expressions && expressions.calculation_chains && (
        <div className="extracted-container">

          <div className="fo-top-row">
            <div className="cp-page-header" style={{ marginBottom: 0 }}>
              <h2 className="cp-page-title">Expression Builder</h2>
              <p className="cp-page-subtitle">
                {expressions.calculation_chains.length} chains · {expressions.calculation_chains.reduce((sum, c) => sum + (c.steps?.length || 0), 0)} steps · base ${baseRevenue.toLocaleString()}
              </p>
            </div>
            <div className="fo-export-row">
              <button className="rr-btn-verify" onClick={downloadExpressions}>Download .json</button>
              <button className="rr-btn-verify" onClick={() => { setExpressions(null); if (onExpressionsBuilt) onExpressionsBuilt(null) }}>
                Rebuild
              </button>
            </div>
          </div>

          {/* Calculation chains */}
          <div className="cp-accordion-container">
            {expressions.calculation_chains.map((chain, index) => (
              <EBChain
                key={index}
                chain={chain}
                index={index}
                expandedChains={expandedChains}
                toggleChain={toggleChain}
                formatCurrency={formatCurrency}
                getOperationSymbol={getOperationSymbol}
                approvedRules={approvedRules}
                pdfFile={pdfFile}
              />
            ))}
          </div>

          {/* Summary — collapsed */}
          <div className="cp-accordion-container" style={{ marginTop: '0.75rem' }}>
            <EBSummary
              expressions={expressions}
              baseRevenue={baseRevenue}
              setBaseRevenue={setBaseRevenue}
              buildExpressions={buildExpressions}
            />
          </div>

          <div className="cp-actions">
            <button className="cp-btn-back" onClick={onBack}>Back to RevShare Rules</button>
            {onContinue && (
              <button className="cp-btn-continue" onClick={onContinue}>
                Continue to RevShare
              </button>
            )}
          </div>

        </div>
      )}
    </div>
  )
}

export default ExpressionBuilder
