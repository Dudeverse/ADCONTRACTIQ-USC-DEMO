import React, { useState } from 'react'
import { parsePageNumber, hasPageInfo } from '../utils/pdfUtils'
import EnhancedPDFViewer from './EnhancedPDFViewer'

const RULE_SOURCE_PAGES = { 1: 1, 2: 2, 3: 4 }

function Section({ title, children, defaultOpen = true }) {
  const [isOpen, setIsOpen] = useState(defaultOpen)
  return (
    <div className="cp-accordion-section">
      <button className="cp-accordion-header" onClick={() => setIsOpen(!isOpen)}>
        <span className="cp-accordion-title">{title}</span>
        <span className={`cp-accordion-chevron ${isOpen ? 'open' : ''}`}>›</span>
      </button>
      {isOpen && <div className="cp-accordion-body">{children}</div>}
    </div>
  )
}

function FinalOutput({ data, expressions, onBack, onReset, onOpenPdf, hasExpressions, onApplyRevenue, pdfFile }) {
  const { rules, contractInfo, summary } = data
  const [pdfOpen, setPdfOpen] = useState(false)
  const [pdfPage, setPdfPage] = useState(1)

  const openSource = (ruleNumber) => {
    const page = RULE_SOURCE_PAGES[ruleNumber] || 1
    setPdfPage(page)
    setPdfOpen(true)
  }

  const formatCurrency = (amount) => new Intl.NumberFormat('en-US', {
    style: 'currency', currency: 'USD',
    minimumFractionDigits: 2, maximumFractionDigits: 2
  }).format(amount)

  const exportJSON = () => {
    const exportData = {
      contract_info: contractInfo,
      finalized_rules: rules.map((rule, index) => ({
        rule_number: index + 1,
        rule_text: rule.rule_text,
        category: rule.category,
        source: rule.source
      })),
      ...(expressions && { calculation_expressions: expressions }),
      summary,
      exported_at: new Date().toISOString(),
      total_rules: rules.length
    }
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `revshare-rules-${contractInfo?.partner_name?.replace(/\s+/g, '-') || 'export'}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  const exportText = () => {
    let text = `# RevShare Rules - ${contractInfo?.partner_name || 'Unknown Partner'}\n\n`
    text += `**Effective Date:** ${contractInfo?.effective_date || 'N/A'}\n`
    text += `**Export Date:** ${new Date().toLocaleDateString()}\n\n`
    rules.forEach((rule, index) => {
      text += `### Rule ${index + 1}\n${rule.rule_group_label || rule.rule_text}\n\n`
      text += `- **Source:** ${rule.source}\n\n`
    })
    const blob = new Blob([text], { type: 'text/markdown' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `revshare-rules-${contractInfo?.partner_name?.replace(/\s+/g, '-') || 'export'}.md`
    a.click()
    URL.revokeObjectURL(url)
  }

  const copyToClipboard = () => {
    let text = `RevShare Rules - ${contractInfo?.partner_name || 'Unknown Partner'}\n\nRules:\n`
    rules.forEach((rule, index) => { text += `${index + 1}. ${rule.rule_group_label || rule.rule_text}\n` })
    navigator.clipboard.writeText(text)
    alert('Copied to clipboard!')
  }

  return (
    <>
      <div className="extracted-container">

        <div className="fo-top-row">
          <div className="cp-page-header" style={{ marginBottom: 0 }}>
            <h2 className="cp-page-title">RevShare 2014 Tony Tony Chopper</h2>
            <p className="cp-page-subtitle">
              {rules.length} rules approved and ready for use.
            </p>
          </div>
          <div className="fo-export-row">
            <button className="rr-btn-verify" onClick={copyToClipboard}>Copy</button>
            <button className="rr-btn-verify" onClick={exportText}>Export .md</button>
            <button className="rr-btn-verify" onClick={exportJSON}>Export .json</button>
            <button className="rr-btn-verify" onClick={() => window.print()}>Print</button>
          </div>
        </div>

        <div className="cp-accordion-container">

          {/* Calculation Expressions — with Approved Rules and View Source inside */}
          {expressions?.calculation_chains?.length > 0 && (
            <Section title={`Calculation Expressions (${expressions.calculation_chains.length})`}>

              {/* Approved RevShare Rules with View Source */}
              <div className="eb-source-rules" style={{ marginBottom: '1.25rem' }}>
                <span className="eb-final-label">Approved RevShare Rules</span>
                {rules.map((rule) => (
                  <div key={rule.rule_number} className="eb-source-rule-row">
                    <span className="cp-summary-text" style={{ flex: 1 }}>
                      {rule.rule_group_label || rule.rule_text}
                    </span>
                    <button
                      className="rr-btn-verify"
                      onClick={() => openSource(rule.rule_number)}
                    >
                      View Source
                    </button>
                  </div>
                ))}
              </div>

              {/* Chains */}
              <div className="fo-chains">
                {expressions.calculation_chains.map((chain, idx) => (
                  <div key={idx} className="fo-chain">
                    <div className="fo-chain-title">{chain.label}</div>
                    {chain.description && <p className="fo-chain-desc">{chain.description}</p>}
                    <div className="fo-steps">
                      {chain.steps?.map((step, stepIdx) => (
                        <div key={stepIdx} className="fo-step-row">
                          <span className="fo-step-num">{step.step_number}</span>
                          <span className="fo-step-label">{step.label}</span>
                          <span className="fo-step-result">{formatCurrency(step.result)}</span>
                        </div>
                      ))}
                    </div>
                    {chain.final_amounts && Object.keys(chain.final_amounts).length > 0 && (
                      <div className="fo-final-amounts">
                        {Object.entries(chain.final_amounts).map(([party, amount]) => (
                          <div key={party} className="fo-amount-row">
                            <span className="fo-party">{party}</span>
                            <span className="fo-amount">{formatCurrency(amount)}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </Section>
          )}

          {/* Approved Rules only — shown when no expressions */}
          {(!expressions?.calculation_chains?.length) && (
            <Section title={`Approved RevShare Rules (${rules.length})`}>
              <div className="fo-rules">
                {rules.map((rule) => (
                  <div key={rule.rule_number} className="fo-rule-row">
                    <div className="fo-rule-top">
                      <span className={`rr-meta-chip category-badge category-${rule.category}`}>
                        {rule.category}
                      </span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '0.75rem' }}>
                      <p className="fo-rule-text" style={{ margin: 0 }}>
                        {rule.rule_group_label || rule.rule_text}
                      </p>
                      <button className="rr-btn-verify" onClick={() => openSource(rule.rule_number)}>
                        View Source
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </Section>
          )}

        </div>

        {/* Actions */}
        <div className="cp-actions" style={{ marginTop: '0.75rem' }}>
          <button className="cp-btn-back" onClick={onBack}>
            {hasExpressions ? 'Back to Expressions' : 'Back to Review'}
          </button>
          <button className="cp-btn-continue" onClick={onApplyRevenue}>
            Apply to Revenue Data
          </button>
        </div>

      </div>

      {/* PDF overlay for View Source */}
      <EnhancedPDFViewer
        file={pdfFile}
        isOpen={pdfOpen}
        onClose={() => setPdfOpen(false)}
        embedded={false}
        initialPage={pdfPage}
      />
    </>
  )
}

export default FinalOutput
