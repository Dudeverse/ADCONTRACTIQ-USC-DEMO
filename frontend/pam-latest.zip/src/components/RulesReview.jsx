import React, { useState } from 'react'
import { CONFIG } from '../config'
import { MOCK_EXPRESSIONS } from '../utils/mockData'
import EnhancedPDFViewer from './EnhancedPDFViewer'

const RULE_SOURCE_PAGES = { 1: 1, 2: 2, 3: 4 }

// ── Mini chain card for inside the rule ───────────────────
function MiniChain({ chain }) {
  const [isOpen, setIsOpen] = useState(false)

  const formatCurrency = (n) => new Intl.NumberFormat('en-US', {
    style: 'currency', currency: 'USD', minimumFractionDigits: 2
  }).format(n)

  return (
    <div className="cp-accordion-section" style={{ background: 'var(--bg-primary)' }}>
      <button className="cp-accordion-header"
        onClick={e => { e.stopPropagation(); setIsOpen(!isOpen) }}
        style={{ padding: '0.6rem 0.75rem' }}>
        <span className="cp-accordion-title" style={{ fontSize: '0.8rem' }}>{chain.label}</span>
        <span className={`cp-accordion-chevron ${isOpen ? 'open' : ''}`}>›</span>
      </button>
      {isOpen && (
        <div className="cp-accordion-body" style={{ padding: '0.5rem 0.75rem 0.75rem' }}>
          {chain.description && (
            <p className="fo-chain-desc">{chain.description}</p>
          )}
          <div className="fo-steps">
            {chain.steps?.map((step, i) => (
              <div key={i} className="fo-step-row">
                <span className="fo-step-num">{step.step_number}</span>
                <span className="fo-step-label">{step.label}</span>
                <span className="fo-step-result">{formatCurrency(step.result)}</span>
              </div>
            ))}
          </div>
          {chain.final_amounts && Object.keys(chain.final_amounts).length > 0 && (
            <div className="fo-final-amounts">
              {Object.entries(chain.final_amounts).map(([party, amount]) => (
                <div key={party} className="fo-amount-row">
                  <span className="fo-party">{party}</span>
                  <span className="fo-amount">{formatCurrency(amount)}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// ── Grouped Rule Card (Demo Mode) ──────────────────────────
function GroupedRuleCard({ rule, onToggle, pdfFile }) {
  const [isOpen, setIsOpen] = useState(false)
  const [pdfOpen, setPdfOpen] = useState(false)

  const chains = MOCK_EXPRESSIONS.calculation_chains || []

  return (
    <>
      <div className={`rr-card ${rule.approved ? 'approved' : ''}`}>
        <div className="rr-header" onClick={() => setIsOpen(!isOpen)}>
          <div className="rr-header-left">
            <label className="rr-mark" onClick={e => e.stopPropagation()}>
              <input
                type="checkbox"
                checked={rule.approved}
                onChange={() => onToggle(rule.rule_number)}
              />
              <span className="rr-checkmark"></span>
            </label>
            <div className="rr-rule-text">{rule.rule_group_label}</div>
          </div>
          <span className={`rr-chevron ${isOpen ? 'open' : ''}`}>›</span>
        </div>

        {isOpen && (
          <div className="rr-body">
            {/* Source and View Source */}
            <div className="rr-actions-row" style={{ marginBottom: '0.75rem' }}>
              <span className="rr-meta-chip rr-source" title={rule.source}>{rule.source}</span>
              <button className="rr-btn-verify" onClick={e => { e.stopPropagation(); setPdfOpen(true) }}>
                View Source
              </button>
              <span className="rr-meta-chip" style={{
                color: '#46d369',
                borderColor: 'rgba(70,211,105,0.4)',
                backgroundColor: 'rgba(70,211,105,0.15)',
              }}>
                {Math.round((rule.confidence || 0.98) * 100)}% Confidence
              </span>
            </div>

            {/* Expression chains */}
            <div className="cp-accordion-container">
              {chains.map((chain, i) => (
                <MiniChain key={i} chain={chain} />
              ))}
            </div>
          </div>
        )}
      </div>

      <EnhancedPDFViewer
        file={pdfFile}
        isOpen={pdfOpen}
        onClose={() => setPdfOpen(false)}
        embedded={false}
        initialPage={rule.source_page || 1}
      />
    </>
  )
}

// ── Standard Rule Card (Real Mode) ────────────────────────
function RuleCard({ rule, onToggle, onDelete, onEdit, onVerify, editingId, editText, setEditText, onSaveEdit, onCancelEdit }) {
  const [isOpen, setIsOpen] = useState(false)

  const getConfidenceColor = (c) => {
    if (c >= 0.85) return '#46d369'
    if (c >= 0.70) return '#f5a623'
    return '#e50914'
  }

  const getConfidenceLabel = (c) => {
    if (c >= 0.85) return 'High'
    if (c >= 0.70) return 'Medium'
    return 'Low'
  }

  const isEditing = editingId === rule.rule_number

  return (
    <div className={`rr-card ${rule.approved ? 'approved' : ''} ${rule.confidence < 0.70 ? 'low-confidence' : ''}`}>
      <div className="rr-header" onClick={() => !isEditing && setIsOpen(!isOpen)}>
        <div className="rr-header-left">
          <label className="rr-mark" onClick={e => e.stopPropagation()}>
            <input type="checkbox" checked={rule.approved} onChange={() => onToggle(rule.rule_number)} />
            <span className="rr-checkmark"></span>
          </label>
          <div className="rr-rule-text">
            {isEditing ? (
              <textarea
                className="rr-edit-textarea"
                value={editText}
                onChange={e => setEditText(e.target.value)}
                rows={2} autoFocus
                onClick={e => e.stopPropagation()}
              />
            ) : (
              <>
                {rule.rule_text}
                {rule.edited && <span className="rr-badge-edited">edited</span>}
                {rule.isNew && <span className="rr-badge-new">new</span>}
              </>
            )}
          </div>
        </div>
        <span className={`rr-chevron ${isOpen ? 'open' : ''}`}>›</span>
      </div>

      {isOpen && (
        <div className="rr-body">
          <div className="rr-meta-row">
            <span className="rr-meta-chip" style={{
              color: getConfidenceColor(rule.confidence),
              borderColor: getConfidenceColor(rule.confidence) + '40',
              backgroundColor: getConfidenceColor(rule.confidence) + '15',
            }}>
              {Math.round(rule.confidence * 100)}% {getConfidenceLabel(rule.confidence)}
            </span>
            <span className="rr-meta-chip rr-source" title={rule.source}>{rule.source}</span>
            <span className={`rr-meta-chip category-badge category-${rule.category}`}>{rule.category}</span>
          </div>
          <div className="rr-actions-row">
            <button className="rr-btn-verify" onClick={e => { e.stopPropagation(); onVerify(rule.source) }}>Verify</button>
            {isEditing ? (
              <>
                <button className="rr-btn-save" onClick={e => { e.stopPropagation(); onSaveEdit(rule.rule_number) }}>Save</button>
                <button className="rr-btn-cancel" onClick={e => { e.stopPropagation(); onCancelEdit() }}>Cancel</button>
              </>
            ) : (
              <button className="rr-btn-edit" onClick={e => { e.stopPropagation(); onEdit(rule) }}>Edit</button>
            )}
            <button className="rr-btn-delete" onClick={e => { e.stopPropagation(); onDelete(rule.rule_number) }}>Remove</button>
          </div>
        </div>
      )}
    </div>
  )
}

// ── Main Component ─────────────────────────────────────────
function RulesReview({ data, onFinalize, onReset, onOpenPdf, pdfFile, onRulesModified, enableExpressions, onContinueToExpressions, finalizedRules }) {
  const initializeRules = () => {
    const baseRules = data.rules || []
    if (finalizedRules?.rules) {
      const finalizedNums = new Set(finalizedRules.rules.map(r => r.rule_number))
      return baseRules.map(rule => ({ ...rule, approved: finalizedNums.has(rule.rule_number) ? true : (rule.approved || false) }))
    }
    return baseRules
  }

  const [rules, setRules] = useState(initializeRules())
  const [editingId, setEditingId] = useState(null)
  const [editText, setEditText] = useState('')
  const [searchKeyword, setSearchKeyword] = useState(null)
  const [contractOpen, setContractOpen] = useState(false)
  const [summaryOpen, setSummaryOpen] = useState(false)

  // Demo mode — only show Rule 1
  const rule1 = rules.find(r => r.rule_number === 1) || rules[0]

  const toggleApproval = (ruleNumber) => {
    setRules(rules.map(r => r.rule_number === ruleNumber ? { ...r, approved: !r.approved } : r))
  }

  const startEdit = (rule) => { setEditingId(rule.rule_number); setEditText(rule.rule_text) }
  const cancelEdit = () => { setEditingId(null); setEditText('') }
  const saveEdit = (ruleNumber) => {
    setRules(rules.map(r => r.rule_number === ruleNumber ? { ...r, rule_text: editText, edited: true } : r))
    setEditingId(null); setEditText('')
    if (onRulesModified) onRulesModified()
  }
  const deleteRule = (ruleNumber) => {
    setRules(rules.filter(r => r.rule_number !== ruleNumber))
    if (onRulesModified) onRulesModified()
  }
  const approveAll = () => setRules(rules.map(r => ({ ...r, approved: true })))

  const handleFinalize = () => {
    const approved = rules.filter(r => r.approved)
    if (approved.length === 0) { alert('Please approve at least one rule before finalizing.'); return }
    onFinalize(approved, data.contract_info, data.glossary, data.summary, data.execution_id)
  }

  const handleContinueToExpressions = () => {
    const approved = rules.filter(r => r.approved)
    if (approved.length === 0) { alert('Please approve at least one rule before continuing.'); return }
    const hasChanged = finalizedRules?.rules &&
      (approved.length !== finalizedRules.rules.length ||
        approved.some(r => !finalizedRules.rules.find(fr => fr.rule_number === r.rule_number)))
    if (hasChanged) {
      if (!confirm(`You've changed which rules are approved. This will clear existing expressions.\n\nContinue?`)) return
      if (onRulesModified) onRulesModified()
    }
    onFinalize(approved, data.contract_info, data.glossary, data.summary, data.execution_id)
    if (onContinueToExpressions) onContinueToExpressions()
  }

  const approvedCount = rules.filter(r => r.approved).length
  const isDemoMode = CONFIG.ENABLE_DEMO_MODE

  return (
    <div className="rr-container">
      <div className="rr-split">
        <div className="rr-left">
          {/* Contract Key Information + Summary — same as page 1 */}
          <div className="cp-accordion-container" style={{ marginBottom: '0.75rem' }}>
            <div className="cp-accordion-section">
              <button className="cp-accordion-header" onClick={() => setContractOpen(!contractOpen)}>
                <span className="cp-accordion-title">Contract Key Information</span>
                <span className={`cp-accordion-chevron ${contractOpen ? 'open' : ''}`}>›</span>
              </button>
              {contractOpen && (
                <div className="cp-accordion-body">
                  <div className="cp-grid">
                    <div className="cp-row"><span className="cp-label">Contract Type</span><span className="cp-value">New</span></div>
                    <div className="cp-row"><span className="cp-label">Business Type</span><span className="cp-value">Media Partner</span></div>
                    <div className="cp-row"><span className="cp-label">Partner</span><span className="cp-value">{data.contract_info?.partner_name || 'TKO Group Holdings / WWE'}</span></div>
                    <div className="cp-row"><span className="cp-label">Effective Start Date</span><span className="cp-value">{data.contract_info?.effective_date || 'January 1, 2025'}</span></div>
                    <div className="cp-row"><span className="cp-label">Effective End Date</span><span className="cp-value">{data.contract_info?.expiration_date || 'December 31, 2034'}</span></div>
                    <div className="cp-row"><span className="cp-label">Payment Term</span><span className="cp-value">Net 45</span></div>
                    <div className="cp-row"><span className="cp-label">Payout Complexity</span><span className="cp-value">Moderate</span></div>
                    <div className="cp-row">
                      <span className="cp-label">AI Confidence</span>
                      <div className="cp-confidence">
                        <div className="cp-confidence-bar">
                          <div className="cp-confidence-fill" style={{ width: '97%', backgroundColor: '#46d369' }} />
                        </div>
                        <span className="cp-confidence-pct">97%</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
            <div className="cp-accordion-section">
              <button className="cp-accordion-header" onClick={() => setSummaryOpen(!summaryOpen)}>
                <span className="cp-accordion-title">Contract Summary</span>
                <span className={`cp-accordion-chevron ${summaryOpen ? 'open' : ''}`}>›</span>
              </button>
              {summaryOpen && (
                <div className="cp-accordion-body">
                  <p className="cp-summary-text">{data.summary || ''}</p>
                </div>
              )}
            </div>
          </div>

          {/* Single Rule — Rule 1 only */}
          <div className="rr-left-header">
            <div className="rr-left-title">
              <span className="rr-title">RevShare Rules</span>
              <span className="rr-subtitle">1 extracted · {approvedCount} approved</span>
            </div>
          </div>

          <div className="rr-rules-list">
            {rule1 && (
              <GroupedRuleCard
                rule={rule1}
                onToggle={toggleApproval}
                pdfFile={pdfFile}
              />
            )}
          </div>

          <div className="rr-left-footer">
            <button className="cp-btn-back" onClick={onReset}>Back</button>
            <button className="cp-btn-continue" onClick={handleFinalize} disabled={approvedCount === 0}>
              Continue to RevShare Simulation
            </button>
          </div>
        </div>

        <div className="rr-right">
          <EnhancedPDFViewer
            file={pdfFile}
            embedded={true}
            searchKeyword={searchKeyword}
          />
        </div>
      </div>
    </div>
  )
}

export default RulesReview
